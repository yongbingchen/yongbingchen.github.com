/* system/debuggerd/peek_stack.c
**
** Copyright 2006, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/ptrace.h>

#include "tombstone.h"
#define LOG_TAG "PeekStack"
#include <utils/Log.h>


int main(int argc, char** argv) 
{
	bool detach_failed = false;
	int total_sleep_time_usec = 0;

	if (argc != 2) {
		printf("Usage: %s [pid] \n", argv[0]);
		return 0;
	}
	pid_t pid = atoi(argv[1]);
	
	ALOGD("peeking stack of process %d\n", pid);
	kill(pid, SIGSTOP);
	ptrace(PTRACE_ATTACH, pid, 0,0);
	char *tombstone_path = engrave_tombstone(pid, 
			pid, 
			0/*no signal*/,
			true /*dump_sibling_threads*/, 
			false /*quiet*/, 
			&detach_failed,
			&total_sleep_time_usec);
	ptrace(PTRACE_DETACH, pid, 0, 0);
	kill(pid, SIGCONT);
	ALOGD("tombstone_path: %s\n", tombstone_path);

	return 0;
}
